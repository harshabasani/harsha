package com.niit.shoes.dao;

public class UserDAO {
	public boolean isValidCredentials(String Uname,String password)
	{
		if(Uname.equals("harsha") && password.equals("12345"))
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}
	

}
