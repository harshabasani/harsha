package com.niit.shopingcart.test;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shopingcart.dao.SupplierDAO;
import com.niit.shopingcart.dao.UserDAO;
import com.niit.shopingcart.model.Supplier;
import com.niit.shopingcart.model.User;
import com.niit.shopingcart.model.UserDetails;

public class UserDetailsTest {
	
public static void main(String[] args) {
		
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.shopingcart");
		context.refresh();
		
	UserDetails u =(UserDetails)	  context.getBean("userDetails");
	
	UserDAO userDAO = (UserDAO)  context.getBean("userDAO");
	

	u.setId("U002");
	u.setName("harsha");
	u.setPassword("harsha");
	u.setEmail("harsha@gmail.com");
	u.setAddress("Hyd");
	u.setMobile("987654321");
	
	
	userDAO.saveOrUpdate(u);

	}

}
