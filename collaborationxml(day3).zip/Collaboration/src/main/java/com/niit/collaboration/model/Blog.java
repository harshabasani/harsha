package com.niit.collaboration.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="blog")
public class Blog {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int bgid;
	
	@NotEmpty(message="title cannot be empty")
	private String bgtitle;
	
	@NotEmpty(message="content cannot be empty")
	private String bgcontent;
	
	private Date creationdatetime;
	
	@NotEmpty(message="username cannot be empty")
	private String bgusername;

	public int getBgid() {
		return bgid;
	}

	public void setBgid(int bgid) {
		this.bgid = bgid;
	}

	public String getBgtitle() {
		return bgtitle;
	}

	public void setBgtitle(String bgtitle) {
		this.bgtitle = bgtitle;
	}

	public String getBgcontent() {
		return bgcontent;
	}

	public void setBgcontent(String bgcontent) {
		this.bgcontent = bgcontent;
	}

	public Date getCreationdatetime() {
		return creationdatetime;
	}

	public void setCreationdatetime(Date creationdatetime) {
		this.creationdatetime = creationdatetime;
	}

	public String getBgusername() {
		return bgusername;
	}

	public void setBgusername(String bgusername) {
		this.bgusername = bgusername;
	}
	
	

}
