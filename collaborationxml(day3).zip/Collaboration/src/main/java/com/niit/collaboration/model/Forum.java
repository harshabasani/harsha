package com.niit.collaboration.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="forum")
public class Forum {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int fmid;
	
	@NotEmpty(message="title cannot be empty")
	private String fmtitle;
	
	@NotEmpty(message="content cannot be empty")
	private String fmcontent;
	
	private Date fmcreationdatetime;
	
	@NotEmpty(message="category cannot be empty")
	private String category;
	
	@NotEmpty(message="user name cannot be empty")
	private String fmusername;

	public int getFmid() {
		return fmid;
	}

	public void setFmid(int fmid) {
		this.fmid = fmid;
	}

	public String getFmtitle() {
		return fmtitle;
	}

	public void setFmtitle(String fmtitle) {
		this.fmtitle = fmtitle;
	}

	public String getFmcontent() {
		return fmcontent;
	}

	public void setFmcontent(String fmcontent) {
		this.fmcontent = fmcontent;
	}

	public Date getFmcreationdatetime() {
		return fmcreationdatetime;
	}

	public void setFmcreationdatetime(Date fmcreationdatetime) {
		this.fmcreationdatetime = fmcreationdatetime;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getFmusername() {
		return fmusername;
	}

	public void setFmusername(String fmusername) {
		this.fmusername = fmusername;
	}

}
