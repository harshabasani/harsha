package com.niit.collaboration.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.collaboration.model.UserDetails;
import com.niit.collaboration.service.UserDetailsService;

@Controller
public class HomeController {
	
	@Autowired
	UserDetailsService userDetailsService;
	
	ModelAndView mv;
	
	@RequestMapping(value = "/onLoad", method = RequestMethod.GET)
	public String onLoad(Model model) {
		System.out.println("onLoad");
		return "/home";
	}
	
	/*@RequestMapping("/")
	public ModelAndView homePage()
	{
		mv = new ModelAndView("/home");
		return mv;
	}*/
	
	@RequestMapping("/register")
	public ModelAndView register()
	{
		mv = new ModelAndView("/register");
		return mv;
	}

	@ModelAttribute("userDetails")
	public UserDetails returnObject()
	{
		return new UserDetails();
	}
}
