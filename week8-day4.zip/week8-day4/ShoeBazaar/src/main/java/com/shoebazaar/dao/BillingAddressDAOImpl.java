package com.shoebazaar.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.shoebazaar.model.BillingAddress;

@Repository("billingAddressDAO")
public class BillingAddressDAOImpl implements BillingAddressDAO{
	
	@Autowired
	private SessionFactory sessionFactory;


	public BillingAddressDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@Transactional
	public List<BillingAddress> list() {
		@SuppressWarnings("unchecked")
		List<BillingAddress> list = (List<BillingAddress>) sessionFactory.getCurrentSession()
				.createCriteria(BillingAddress.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return list;
	}
	
	@Transactional
	public void saveOrUpdate(BillingAddress billingAddress) {
		System.out.println("into DAOImpl-billing");
		sessionFactory.getCurrentSession().saveOrUpdate(billingAddress);
	}
	
	@Transactional
	public void delete(String id) {
		BillingAddress BillingAddressToDelete = new BillingAddress();
		BillingAddressToDelete.setName(id);
		sessionFactory.getCurrentSession().delete(BillingAddressToDelete);
	}

	@Transactional
	public BillingAddress get(String id) {
		String hql = "from BillingAddress where id=" + "'" + id + "'";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		
		@SuppressWarnings("unchecked")
		List<BillingAddress> list = (List<BillingAddress>) query.list();
		
		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}
		
		return null;
	}

}
