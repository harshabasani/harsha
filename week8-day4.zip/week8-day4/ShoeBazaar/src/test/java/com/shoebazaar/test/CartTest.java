package com.shoebazaar.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.shoebazaar.dao.CartDAO;
import com.shoebazaar.model.Cart;

public class CartTest {

	public static void main(String[] args) {

		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.shoebazaar");
		context.refresh();
		
		Cart c = (Cart) context.getBean("cart");
		CartDAO cartDAO = (CartDAO) context.getBean("cartDAO");
		
		c.setId(1);
		c.setPrice(2400);
		c.setProductName("adidas");
		c.setQuantity(1);
		c.setStatus('N');
		c.setUserID("user");
		
		cartDAO.saveOrUpdate(c);
	}

}
