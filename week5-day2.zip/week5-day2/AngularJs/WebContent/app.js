var app=angular.module('shoppingCart',['ngRoute']);
app.controller('HomeController',function($scope)
     {
	  $scope.message='hello from HomeController';
     }	);
app.controller('CategoryController',function($scope)
	     {
		  $scope.message='hello from CategoryController';
	     }	);
app.controller('ProductController',function($scope)
	     {
		  $scope.message='hello from ProductController';
	     }	);
app.controller('SupplierController',function($scope)
	     {
		  $scope.message='hello from SupplierController';
	     }	);

app.config(function($routeProvider)
 {
	$routeProvider
	  .when('/',{templateUrl:'home.html',controller:'HomeController'})
	  .when('/categories',{templateUrl:'views/categories.html',controller:'CategoryController'})
	  .when('/prducts',{templateUrl:'views/products.html',controller:'ProductController'})
	  .when('/suppliers',{templateUrl:'views/suppliers.html',controller:'SupplierController'})
	
	  .otherwise({redirectTo:'/'});
 }	);