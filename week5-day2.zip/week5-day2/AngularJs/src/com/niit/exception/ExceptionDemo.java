package com.niit.exception;

public class ExceptionDemo {

	public double divide(int x,int y)
	{
		return x/y;
	}
	
	public static void main(String[] args)
	{
		ExceptionDemo e = new ExceptionDemo();
		try {
			int x=Integer.parseInt(args[0]);
			int y=Integer.parseInt(args[1]);
			System.out.println(x/y);
		}
		catch (ArithmeticException e1) {
			System.out.println("second parameter should not be zero");
			}
		catch (ArrayIndexOutOfBoundsException e1) {
			System.out.println("please give two parameters");
			}
		catch (NumberFormatException e1) {
			System.out.println("please give integer number");
			}
	}
}
