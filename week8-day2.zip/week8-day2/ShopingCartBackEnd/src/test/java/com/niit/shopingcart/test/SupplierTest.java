package com.niit.shopingcart.test;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shopingcart.dao.SupplierDAO;
import com.niit.shopingcart.model.Supplier;

public class SupplierTest {
	
	
	public static void main(String[] args) {
		
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.shopingcart");
		context.refresh();
		
	Supplier s =(Supplier)	  context.getBean("supplier");
	
	SupplierDAO supplierDAO = (SupplierDAO)  context.getBean("supplierDAO");
	

	s.setId("SP003");
	s.setName("local");
	s.setAddress("hyderabad");
	
	
	supplierDAO.saveOrUpdate(s);

	
	
	
	List<Supplier>  list =    supplierDAO.list();
	
	for(Supplier sup : list)
	{
		System.out.println(sup.getId()  + ":" + sup.getName()  + ":"+  sup.getAddress());
	}
		
		
	}

}
