package com.niit.shopingcart.testcase;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shopingcart.dao.SupplierDAO;


public class SupplierTestCase {

	AnnotationConfigApplicationContext context;
	SupplierDAO supplierDAO;
	@Before
	public void init()
	{
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.shopingcart");
		context.refresh();
	    supplierDAO = (SupplierDAO) context.getBean("supplierDAO");
	}
	@Test
	public void CategoryTest()
	{
		assertEquals("supplier list",5,supplierDAO.list().size());
	}

}
