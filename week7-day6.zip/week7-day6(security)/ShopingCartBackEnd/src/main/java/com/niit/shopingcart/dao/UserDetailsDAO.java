package com.niit.shopingcart.dao;

import java.util.List;
import com.niit.shopingcart.model.UserDetails;



public interface UserDetailsDAO {


	public List<UserDetails> list();

	public UserDetails get(String id);

	public void saveOrUpdate(UserDetails userDetails);
	
	//public void saveOrUpdate(UserDetails userDetails);

	public void delete(int id);
	
	public boolean isValidUser(String name, String password, boolean isAdmin);


}
