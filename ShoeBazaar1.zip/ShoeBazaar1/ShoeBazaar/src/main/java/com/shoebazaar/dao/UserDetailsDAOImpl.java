package com.shoebazaar.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import com.shoebazaar.model.UserDetails;

@Repository("userDetailsDAO")
public class UserDetailsDAOImpl implements UserDetailsDAO {
	
	Logger log = LoggerFactory.getLogger("UserDetailsDAOImpl.class");

	@Autowired
	private SessionFactory sessionFactory;


	public UserDetailsDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
  
	@Transactional
	public List<UserDetails> list() {
		System.out.println("***********list called in UserDetailsDAOImpl*********");
		
		@SuppressWarnings("unchecked")
		List<UserDetails> list = (List<UserDetails>) sessionFactory.getCurrentSession()
				.createCriteria(UserDetails.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		return list;
	}

	@Transactional
	public void saveOrUpdate(UserDetails userDetails) {
		System.out.println("***********saveOrUpdate called in UserDetailsDAOImpl*********");
		
		sessionFactory.getCurrentSession().saveOrUpdate(userDetails);
		
	}
	

	@Transactional
	public void delete(int id) {
		System.out.println("***********delete called in UserDetailsDAOImpl*********");
		
		UserDetails userDetails = new UserDetails();
		userDetails.setId(id);
		sessionFactory.getCurrentSession().delete(userDetails);
		
	}

	@Transactional
	public UserDetails get(String id) {
		System.out.println("***********get called in UserDetailsDAOImpl*********");
		String hql = "from UserDetails where id="  + id ;
		
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		
		@SuppressWarnings("unchecked")
		List<UserDetails> list = (List<UserDetails>) query.list();
		
		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}
		
		return null;
	}
	
	public List<UserDetails> viewUserDetails()
	{
		System.out.println("***********viewUserDetails called in UserDetailsDAOImpl*********");
		Session session = sessionFactory.getCurrentSession();
		Transaction transaction = session.beginTransaction();
		@SuppressWarnings("unchecked")
		List<UserDetails> list = session.createCriteria(UserDetails.class).list();
		return list;
	}


}
