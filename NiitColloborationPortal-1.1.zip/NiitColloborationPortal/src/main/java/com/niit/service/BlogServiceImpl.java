package com.niit.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niit.dao.*;
import com.niit.model.*;
import java.util.*;

@Service
public class BlogServiceImpl implements BlogService
{
	@Autowired
	BlogDaoInterface blogdao;
	
	public void createNewBlog(Blog blog)
	{
		System.out.println("************createNewBlog called in BlogServiceImpl*********");
		blogdao.createNewBlog(blog);
	}
	
	public List<Blog> getBlogList(String bUserName)
	{
		System.out.println("************getBlogList called in BlogServiceImpl*********");
		return blogdao.getBlogList(bUserName);
	}
	
	public Blog getBlogById(int bid)
	{
		System.out.println("************getBlogById called in BlogServiceImpl*********");
		return new Blog();
	}
	
	public Blog getBlogByName(String bname)
	{
		System.out.println("************getBlogByName called in BlogServiceImpl*********");
		return new Blog();
	}
	
	
	public List<Blog> getBlog()
	{
		System.out.println("************getBlog called in BlogServiceImpl*********");
		return blogdao.getBlog();
	}
}
