package com.shoebazaar.test;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.shoebazaar.dao.CategoryDAO;
import com.shoebazaar.dao.ProductDAO;
import com.shoebazaar.dao.SupplierDAO;
import com.shoebazaar.model.Category;
import com.shoebazaar.model.Product;
import com.shoebazaar.model.Supplier;

public class ProductTest {
	
	
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.shoebazaar");
		context.refresh();
		
		Product p = (Product)context.getBean("product");
		
	  
	    p.setId("PD007");
	    p.setName("puma canvas shoes");
	    p.setDescription("color:blue");
	    p.setPrice(2399);
	    
	   
	    p.setSupplier_id("SP002");
	    p.setCategory_id("CT001");
	
	    ProductDAO productDAO = (ProductDAO)context.getBean("productDAO");
	    productDAO.saveOrUpdate(p);
		
		
	}

}
