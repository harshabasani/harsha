package com.shoebazaar.test;



import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.shoebazaar.dao.UserDetailsDAO;
import com.shoebazaar.model.UserDetails;

public class UserDetailsTest {
	
public static void main(String[] args) {
		
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.shoebazaar");
		context.refresh();
		
	UserDetails u =(UserDetails)	  context.getBean("userDetails");
	
	UserDetailsDAO userDetailsDAO = (UserDetailsDAO)  context.getBean("userDetailsDAO");
	


	u.setName("niit");
	u.setPassword("niit");
	u.setMobile("9123654781");
	u.setEmail("niit@gmail.com");
	u.setAddress("Hyd");
	u.setGender("male");
	
	
	userDetailsDAO.saveOrUpdate(u);

	}

}
