package com.shoebazaar.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.shoebazaar.dao.CartDAO;
import com.shoebazaar.dao.CategoryDAO;
import com.shoebazaar.model.Category;
import com.shoebazaar.util.Util;


@SessionAttributes({ "table" })  
@Controller
public class CategoryController {
	@Autowired
	private CategoryDAO categoryDAO;
	
	@Autowired
	private CartDAO cartDAO;
	
	
	@RequestMapping(value = "/onLoad", method = RequestMethod.GET)
	public String onLoad(Model model) {
		System.out.println("**********onLoad called in CategoryController***********");
		model.addAttribute("category", new Category());
		model.addAttribute("categoryList", this.categoryDAO.list());
		model.addAttribute("cartSize", this.cartDAO.list().size());
		return "/home";
	}
	

	@RequestMapping(value = "/onLoad1", method = RequestMethod.GET)
	public String onLoad1(Model model) {
		System.out.println("************onLoad1 called in CategoryController************");
		model.addAttribute("category", new Category());
		model.addAttribute("categoryList", this.categoryDAO.list());
		model.addAttribute("cartSize", this.cartDAO.list().size());
		return "/userHome";
	}
	
	@RequestMapping(value = "/backToAdminHome", method = RequestMethod.GET)
	public String backToAdminHome(Model model) {
		System.out.println("**************backToAdminHome called in CategoryController*************");
		return "/adminHome";
	}
	
	
	@RequestMapping(value = "/categories", method = RequestMethod.GET)
	public String listCategories(Model model) {
		System.out.println("************listCategories called in CategoryController***********");
		model.addAttribute("category", new Category());
		model.addAttribute("categoryList", this.categoryDAO.list());
		return "category";
	}
	
	//For add and update category both
	@RequestMapping(value= "/category/add", method = RequestMethod.POST)
	public String addCategory(@ModelAttribute("category") Category category){
		System.out.println("************addCategory called in CategoryController***********");
		Util u=new Util();
		String newId=u.replace(category.getId(),",","");
		category.setId(newId);
	
			categoryDAO.saveOrUpdate(category);
		
		return "redirect:/categories";
		
	}
	
	@RequestMapping("category/delete/{id}")
    public String deleteCategory(@PathVariable("id") String id,ModelMap model) throws Exception{
		System.out.println("************deleteCategory called in CategoryController***********");
       try {
		categoryDAO.delete(id);
		model.addAttribute("message","Successfully Added");
	} catch (Exception e) {
		model.addAttribute("message",e.getMessage());
		e.printStackTrace();
	}
        return "redirect:/categories";
    }
 
    @RequestMapping("category/edit/{id}")
    public String editCategory(@PathVariable("id") String id, Model model){
    	System.out.println("************editCategory called in CategoryController***********");
        model.addAttribute("category", this.categoryDAO.get(id));
        model.addAttribute("listCategory", this.categoryDAO.list());
        return "category";
    }


	}
