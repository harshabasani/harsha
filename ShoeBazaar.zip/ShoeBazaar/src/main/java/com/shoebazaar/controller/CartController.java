package com.shoebazaar.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.shoebazaar.dao.CartDAO;
import com.shoebazaar.dao.CategoryDAO;
import com.shoebazaar.dao.ProductDAO;
import com.shoebazaar.model.Cart;
import com.shoebazaar.model.Category;
import com.shoebazaar.model.Product;


@Controller
public class CartController {
	
	
	@Autowired(required=true)
	private CartDAO cartDAO;
	
	@Autowired(required=true)
	private ProductDAO productDAO;
	
	@Autowired(required=true)
	private CategoryDAO categoryDAO;

	@RequestMapping(value = "/myCart", method = RequestMethod.GET)
	public String myCart(Model model) {
		System.out.println("************myCart called in CartController***********");
		model.addAttribute("category", new Category());
		model.addAttribute("categoryList", categoryDAO.list());
	
		model.addAttribute("cart", new Cart());
		model.addAttribute("cartList", this.cartDAO.list());
		model.addAttribute("totalAmount", cartDAO.getTotalAmount("harsha")); // Just for testing, password harsha
		model.addAttribute("cartSize", this.cartDAO.list().size());
		model.addAttribute("displayCart", "true");
		return "/userHome";
	}
	
	
	//For add and update cart both
	@RequestMapping(value= "cart/add/{id}" , method = RequestMethod.GET)
	public String addToCart(@PathVariable("id") String id){
		System.out.println("************addToCart called in CartController***********");
	 Product product =	 productDAO.get(id);
	 Cart cart = new Cart();
	 cart.setId(product.getId());
	 cart.setPrice(product.getPrice());
	 cart.setProductName(product.getName());
	 cart.setQuantity(1);
	 cart.setUserID("harsha");
	 cart.setStatus('N');
		cartDAO.saveOrUpdate(cart);

		return "redirect:/userHome";
		
	}
	
	@RequestMapping(value= "usercart/add/{id}" , method = RequestMethod.GET)
	public String addToCart1(@PathVariable("id") String id){
		System.out.println("************addToCart1 called in CartController***********");
	 Product product =	 productDAO.get(id);
	 Cart cart = new Cart();
	 cart.setId(product.getId());
	 cart.setPrice(product.getPrice());
	 cart.setProductName(product.getName());
	 cart.setQuantity(1);
	 cart.setUserID("harsha");
	 cart.setStatus('N');
		cartDAO.saveOrUpdate(cart);

		return "redirect:/userHome";
		
	}
	
	@RequestMapping("cart/remove/{id}")
    public String removeCart(@PathVariable("id") String id,ModelMap model) throws Exception{
		System.out.println("************removeCart called in CartController***********");
	       try {
			cartDAO.delete(id);
			model.addAttribute("message","Successfully Removed");
		} catch (Exception e) {
			model.addAttribute("message",e.getMessage());
			e.printStackTrace();
		}
	        return "redirect:/myCart";
	    }
		
    @RequestMapping("cart/edit/{id}")
    public String editCart(@PathVariable("id") String id, Model model){
    	System.out.println("************editCart called in CartController***********");
        model.addAttribute("cart", this.cartDAO.get(id));
        model.addAttribute("listCarts", this.cartDAO.list());
        return "cart";
    }
       
	}
