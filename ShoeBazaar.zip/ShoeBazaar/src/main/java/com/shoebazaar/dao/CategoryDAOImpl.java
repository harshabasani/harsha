package com.shoebazaar.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.shoebazaar.model.Category;

@Repository("categoryDAO")
public class CategoryDAOImpl implements CategoryDAO {
	
	public CategoryDAOImpl()
	{
		
	}
	
	private static final Logger log = LoggerFactory.getLogger("CategoryDAOImpl.class");
	
	@Autowired
	private SessionFactory sessionFactory;


	public CategoryDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public List<Category> list() {
		System.out.println("***********list called in CategoryDAOImpl*********");
		log.debug("start calling list");
		Session s = sessionFactory.getCurrentSession();
		Transaction t = s.beginTransaction();
		@SuppressWarnings("unchecked")
		List<Category> listCategory = (List<Category>) sessionFactory.getCurrentSession().createCriteria(Category.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		
		t.commit();
		log.debug("end calling list");
		return listCategory;
		
	}
	

	@Transactional
	public void saveOrUpdate(Category category) {
		System.out.println("***********saveOrUpdate called in CategoryDAOImpl*********");
		Session s = sessionFactory.getCurrentSession();
		Transaction t = s.beginTransaction();
		sessionFactory.getCurrentSession().saveOrUpdate(category);
		t.commit();
	}

	@Transactional
	public void delete(String id) {
		System.out.println("***********delete called in CategoryDAOImpl*********");
		Session s = sessionFactory.getCurrentSession();
		Transaction t = s.beginTransaction();
		Category CategoryToDelete = new Category();
		CategoryToDelete.setId(id);
		sessionFactory.getCurrentSession().delete(CategoryToDelete);
		t.commit();
	}

	@Transactional
	public Category get(String id) {
		System.out.println("***********get called in CategoryDAOImpl*********");
		log.debug("start calling get");
		String hql = "from Category where id=" + "'"+ id +"'";
		Session s = sessionFactory.getCurrentSession();
		Transaction t = s.beginTransaction();
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		
		@SuppressWarnings("unchecked")
		List<Category> listCategory = (List<Category>) query.list();
		
		if (listCategory != null && !listCategory.isEmpty()) {
			return listCategory.get(0);
		}
		t.commit();
		log.debug("end calling get");
		return null;
	}
	
	
	@Transactional
	public Category getByName(String name) {
		System.out.println("***********getByName called in CategoryDAOImpl*********");
		String hql = "from Category where name=" + "'"+ name +"'";
		Session s = sessionFactory.getCurrentSession();
		Transaction t = s.beginTransaction();
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		
		@SuppressWarnings("unchecked")
		List<Category> listCategory = (List<Category>) query.list();
		
		if (listCategory != null && !listCategory.isEmpty()) {
			return listCategory.get(0);
		}
		t.commit();
		return null;
	}


}
