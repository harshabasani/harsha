package com.shoebazaar.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.shoebazaar.model.BillingAddress;

@Repository("billingAddressDAO")
public class BillingAddressDAOImpl implements BillingAddressDAO{
	
	public BillingAddressDAOImpl()
	{
		
	}
	
	@Autowired
	private SessionFactory sessionFactory;


	public BillingAddressDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	/*@Transactional
	public List<BillingAddress> list() {
		System.out.println("***********list called in BillingAddressDAOImpl*********");
		Session s = sessionFactory.getCurrentSession();
		Transaction t = s.beginTransaction();
		@SuppressWarnings("unchecked")
		List<BillingAddress> list = (List<BillingAddress>) sessionFactory.getCurrentSession()
				.createCriteria(BillingAddress.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
        t.commit();
		return list;
	}*/
	
	@Transactional
	public void saveOrUpdate(BillingAddress billingAddress) {
		System.out.println("***********saveOrUpdate called in BillingAddressDAOImpl*********");
		Session s = sessionFactory.getCurrentSession();
		Transaction t = s.beginTransaction();
		sessionFactory.getCurrentSession().saveOrUpdate(billingAddress);
		t.commit();
	}
	
	/*@Transactional
	public void delete(int id) {
	System.out.println("***********delete called in BillingAddressDAOImpl*********");
		Session s = sessionFactory.getCurrentSession();
		Transaction t = s.beginTransaction();
		BillingAddress BillingAddressToDelete = new BillingAddress();
		BillingAddressToDelete.setId(id);
		sessionFactory.getCurrentSession().delete(BillingAddressToDelete);
		t.commit();
	}*/

	/*@Transactional
	public BillingAddress get(String id) {
	System.out.println("***********get called in BillingAddressDAOImpl*********");
		String hql = "from BillingAddress where id=" + id ;
		Session s = sessionFactory.getCurrentSession();
		Transaction t = s.beginTransaction();
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		
		@SuppressWarnings("unchecked")
		List<BillingAddress> list = (List<BillingAddress>) query.list();
		
		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}
		t.commit();
		return null;
	}*/

}
