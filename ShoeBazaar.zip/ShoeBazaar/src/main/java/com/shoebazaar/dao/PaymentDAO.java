package com.shoebazaar.dao;

import com.shoebazaar.model.Payment;

public interface PaymentDAO {
	
	public void saveOrUpdate(Payment payment);

}
