package com.niit.shopingcart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shopingcart.dao.BillingAddressDAO;
import com.niit.shopingcart.model.BillingAddress;


@Controller
public class BillingAddressController {
	
	@Autowired
	BillingAddressDAO billingAddressDAO;

	/*@RequestMapping("home")
	public String home(){
		System.out.println("in to billing-controller");
		return "index1";
	}*/
	
	@RequestMapping(value= "/billing", method = RequestMethod.POST)
	public ModelAndView billingUser(@ModelAttribute BillingAddress billingAddress) {
		System.out.println("in to controller-billing");
		billingAddressDAO.saveOrUpdate(billingAddress);
	
	  return new ModelAndView("/payment");
	 }
}
