package com.niit.collaboration.controller;

import java.io.File;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.niit.collaboration.model.UserDetails;
import com.niit.collaboration.service.UserDetailsService;

@Controller
public class UserDetailsController {
	
	@Autowired
	UserDetailsService userDetailsService;
	
	ModelAndView mv;
	
	@RequestMapping("/register")
	public String createUser(@ModelAttribute("userDetails") UserDetails userDetails , Model model,HttpServletRequest request, MultipartFile file) throws IOException
	{
		
		String filename = null;
	    byte[] bytes;
	    
	    		//userDetails.setRole("ROLE_USER");
	    		userDetails.setActive(true);
	            userDetailsService.saveOrUpdate(userDetails);
	    		System.out.println("Data Inserted");
	            //String path = request.getSession().getServletContext().getRealPath("/resources/images/" + user.getUserid() + ".jpg");
	    		MultipartFile image = userDetails.getImage();
	            //Path path;
	            String path = request.getSession().getServletContext().getRealPath("/resources/images/"+userDetails.getId()+".jpg");
	            System.out.println("Path="+path);
	            System.out.println("File name = " + userDetails.getImage().getOriginalFilename());
	          
	            if(image!=null && !image.isEmpty())
	            {
	            	try
	            	{
	            		image.transferTo(new File(path.toString()));
	            		System.out.println("Image saved  in:"+path.toString());
	            	}
	            	catch(Exception e)
	            	{
	            		e.printStackTrace();
	            		System.out.println("Image not saved");
	            	}
	            }
	    	
	     	    
	    return "LoginPage";
	
		
	}
	
	@ModelAttribute("userDetails")
	public  UserDetails returnObject()
	{
		return new UserDetails();
	}

	@RequestMapping("/reg")
	public ModelAndView RegPage()
	{
		mv = new ModelAndView("register");
		return mv;
	}
	
	@RequestMapping("/login")
	public ModelAndView LoginP()
	{
		mv = new ModelAndView("login");
		return mv;
	}
}
