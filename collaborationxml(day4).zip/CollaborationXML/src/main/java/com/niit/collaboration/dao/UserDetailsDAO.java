package com.niit.collaboration.dao;

import java.util.List;

import com.niit.collaboration.model.UserDetails;

public interface UserDetailsDAO {
	
	public void saveOrUpdate(UserDetails userDetails);
	
	/*public List<UserDetails> list();
	
	public UserDetails getUserDetailsByName(String name);
	
	public UserDetails getUserDetailsById(int id);*/

}
