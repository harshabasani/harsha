package com.niit.collaboration.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {
	
	
	
	ModelAndView mv;
	
	@RequestMapping("/")
	public String home(Model model) {
		System.out.println("home");
		return "/home";
	}
	
}
