package com.niit.collaboration.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.niit.collaboration.dao.UserDetailsDAO;
import com.niit.collaboration.model.UserDetails;

@Service
public class UserDetailsServiceImpl implements UserDetailsService{
	
	@Autowired
	private UserDetailsDAO userDetailsDAO;
	
	@Transactional
	public void setUserDetailsDAO(UserDetailsDAO userDetailsDAO)
	{
		this.userDetailsDAO=userDetailsDAO;
	}

	@Transactional
	public void saveOrUpdate(UserDetails userDetails) {
		userDetailsDAO.saveOrUpdate(userDetails);
		
	}
	
	/*@Transactional
	public List<UserDetails> list() {
		
		return userDetailsDAO.list();
	}
	

	@Transactional
	public UserDetails getUserDetailsByName(String name) {
		
		return userDetailsDAO.getUserDetailsByName(name);
	}

	@Transactional
	public UserDetails getUserDetailsById(int id) {
		
		return userDetailsDAO.getUserDetailsById(id);
	}*/

	


}
