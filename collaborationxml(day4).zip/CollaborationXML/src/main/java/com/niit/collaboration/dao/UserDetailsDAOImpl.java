package com.niit.collaboration.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.collaboration.model.UserDetails;

@Repository
@Transactional
public class UserDetailsDAOImpl implements UserDetailsDAO{
	
	public UserDetailsDAOImpl()
	{
		
	}
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory)
	{
		this.sessionFactory = sessionFactory;
	}
	
	public void saveOrUpdate(UserDetails userDetails)
	{
		Session s = sessionFactory.getCurrentSession();
		Transaction t = s.beginTransaction();
		s.saveOrUpdate(userDetails);
		t.commit();
	}
	
	/*@Override
	public List<UserDetails> list()
	{
		@SuppressWarnings("unchecked")
		Session session = this.sessionFactory.getCurrentSession();
		
		@SuppressWarnings("unchecked")
		List<UserDetails> userDetails = sessionFactory.getCurrentSession().createCriteria(UserDetails.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		return userDetails;
	}
	
	@SuppressWarnings("unchecked")
	public UserDetails getUserDetailsByName(String name) {
		
		System.out.println("getting data in dao based on name"+name);
		
		Session session=this.sessionFactory.getCurrentSession();
		Transaction tx=session.beginTransaction();
		
		Criteria cr=session.createCriteria(UserDetails.class);
		cr.add(Restrictions.eq("name", name));
		List<UserDetails> users = cr.list();
		UserDetails userDetails = users.get(0);
		
		System.out.println("User Data="+userDetails.getName());
		
		tx.commit();
		return userDetails;
	}
	
	@Override
	public UserDetails getUserDetailsById(int id) {
		Session session=this.sessionFactory.getCurrentSession();
		Transaction tx=session.beginTransaction();
		
		UserDetails u=(UserDetails) session.load(UserDetails.class,id);
		
		System.out.println("data of user by id="+u);
		
		tx.commit();
		return u;	
	}*/
	

}
