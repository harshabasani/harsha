package com.niit.collaboration.service;

import java.util.List;

import com.niit.collaboration.model.UserDetails;

public interface UserDetailsService {
	
    public void saveOrUpdate(UserDetails userDetails);
	
	/*public List<UserDetails> list();
	
	public UserDetails getUserDetailsByName(String name);
	
	public UserDetails getUserDetailsById(int id);*/

}
