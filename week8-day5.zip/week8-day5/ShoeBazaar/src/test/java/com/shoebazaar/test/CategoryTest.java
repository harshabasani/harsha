package com.shoebazaar.test;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.shoebazaar.dao.CategoryDAO;
import com.shoebazaar.model.Category;

public class CategoryTest {
	
	
	public static void main(String[] args) {
		
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.shoebazaar");
		context.refresh();
		
	Category c =(Category)	  context.getBean("category");
	
	CategoryDAO categoryDAO = (CategoryDAO)  context.getBean("categoryDAO");
	

	c.setId("CT002");
	c.setName("sneakers");
	c.setDescription("sneakers for sports");
	
	
	categoryDAO.saveOrUpdate(c);

	
	
	
	List<Category>  list =    categoryDAO.list();
	
	for(Category cat : list)
	{
		System.out.println(cat.getId()  + ":" +  cat.getName()  + ":"+  cat.getDescription());
	}
		
		
	}

}
